# E-Bike Shopping Website

# Features

- Interactive UI
- Create using React JS + vite
- Used Tailwind CSS
- Used React Router
- Fully Responsive


## Authors

- [@Raktimmaity](https://github.com/Raktimmaity)


## Screenshots

![App Screenshot](./bike.png)


## Demo
https://ebike-raktimmaitys-projects.vercel.app/